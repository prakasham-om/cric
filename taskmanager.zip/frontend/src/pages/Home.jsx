import TrelloBoard from "../components/TaskBoard ";
import Footer from "../components/Footer";

const Home = () => {
  return (
    <div>
      <TrelloBoard />
      <Footer />
    </div>
  );
};
export default Home;
